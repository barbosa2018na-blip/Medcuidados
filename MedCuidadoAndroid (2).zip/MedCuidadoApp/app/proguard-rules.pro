# MedCuidado ProGuard Rules
-keep class br.com.medcuidado.** { *; }
-keep class com.google.mlkit.** { *; }
-keepattributes *Annotation*
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
